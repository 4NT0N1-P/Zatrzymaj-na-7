package pl.zstradom.antoni.zatrzymajna7;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvScore;
    private TextView tvCounter;
    private TextView tvMessage;
    private Button btnStart;
    private Button btnStop;

    private int currentDigit = 0;
    private int hits = 0;
    private boolean isRunning = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable counterRunnable = new Runnable() {
        @Override
        public void run() {
            if (isRunning) {
                currentDigit = (currentDigit + 1) % 10;
                tvCounter.setText(String.valueOf(currentDigit));
                handler.postDelayed(this, 500);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvScore = findViewById(R.id.tvScore);
        tvCounter = findViewById(R.id.tvCounter);
        tvMessage = findViewById(R.id.tvMessage);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);

        btnStart.setOnClickListener(v -> startGame());
        btnStop.setOnClickListener(v -> stopGame());
    }

    private void startGame() {
        currentDigit = 0;
        isRunning = true;

        tvCounter.setText("0");
        tvMessage.setText("");

        btnStart.setEnabled(false);
        btnStop.setEnabled(true);

        handler.removeCallbacks(counterRunnable);
        handler.postDelayed(counterRunnable, 500);
    }

    private void stopGame() {
        isRunning = false;
        handler.removeCallbacks(counterRunnable);

        btnStart.setEnabled(true);
        btnStop.setEnabled(false);

        if (currentDigit == 7) {
            hits++;
            tvScore.setText("Trafienia: " + hits);
            tvMessage.setText("Trafienie!");
        } else {
            tvMessage.setText("Pudło! Zatrzymano na " + currentDigit);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(counterRunnable);
    }
}
